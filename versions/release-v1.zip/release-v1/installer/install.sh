#!/bin/bash

# ── Detect the directory where this script is ──
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

TARGET_DIR="$HOME/nevo"

mkdir $HOME/nevo

# ── Compiling the compiler
echo "Compiling Nevo Compiler..."
clang "../compiler.c" "../errors.c" -I.. -o compiler "$TARGET_DIR/compiler"
clang "../transpiler.c" -o transpiler "$TARGET_DIR/transpiler"

# ── Done!
echo "✅ Done! Everything You Need Is Inside Of $TARGET_DIR"
read -p "Press Enter To Continue..."

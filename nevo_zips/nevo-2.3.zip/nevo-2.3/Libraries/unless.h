#ifndef UNLESS_H
#define UNLESS_H

#pragma once

#define unless(cond) if (!(cond))


#endif
#ifndef CURSES_H
#define CURSES_H

// Censors banned words in a line, unless inside a string literal
void censor_line(char *line);

#endif // CURSES_H

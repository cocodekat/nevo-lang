#!/bin/bash
echo "Removing nevo"
rm -rf "$HOME/nevo"

echo "Uninstall complete."
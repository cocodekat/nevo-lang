#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINE_MAX 8192
#define STACK_MAX 128

char *stack[STACK_MAX];
int stack_top = 0;

// Write a substring to a file
static void write_substr(FILE *out, const char *s, size_t start, size_t len) {
    fwrite(s + start, 1, len, out);
}

// Unescape quoted substring into malloc'd buffer (handles \" and \\)
static char *unescape(const char *src, size_t len) {
    char *out = malloc(len + 1);
    if (!out) return NULL;
    size_t oi = 0;
    for (size_t i = 0; i < len; ++i) {
        if (src[i] == '\\' && i + 1 < len) {
            char nxt = src[i + 1];
            if (nxt == '"' || nxt == '\\') {
                out[oi++] = nxt;
                i++;
            } else {
                out[oi++] = src[i];
            }
        } else {
            out[oi++] = src[i];
        }
    }
    out[oi] = '\0';
    return out;
}

// Push a tag onto the stack and write opening tag with newline and indentation
static void push_tag(FILE *out, const char *tag) {
    if (stack_top >= STACK_MAX) {
        fprintf(stderr, "Error: too many nested tags\n");
        exit(1);
    }
    stack[stack_top++] = strdup(tag);
    for (int k = 0; k < stack_top - 1; k++) fputs("  ", out); // indent
    fprintf(out, "<%s>\n", tag);
}

// Pop a tag from the stack and write closing tag with newline and indentation
static void pop_tag(FILE *out) {
    if (stack_top == 0) return;
    stack_top--;
    for (int k = 0; k < stack_top; k++) fputs("  ", out); // indent
    fprintf(out, "</%s>\n", stack[stack_top]);
    free(stack[stack_top]);
}

// Trim trailing spaces
static char *trim_end(char *s) {
    // Trim leading
    while (*s && isspace((unsigned char)*s)) s++;
    // Trim trailing
    char *end = s + strlen(s) - 1;
    while (end >= s && isspace((unsigned char)*end)) *end-- = '\0';
    return s;
}

// Process a single line
static void process_line(FILE *out, char *line) {
    char *s = trim_end(line);

    // Closing brace
    if (strcmp(s, "}") == 0) {
        pop_tag(out);
        return;
    }

    // Opening brace like "div {"
    size_t len = strlen(s);
    if (len >= 2 && s[len - 1] == '{') {
        s[len - 1] = '\0';
        char *tag = trim_end(s);
        push_tag(out, tag);
        return;
    }

    // Inline tags or text
    size_t n = strlen(s);
    size_t i = 0;
    int inside_html_tag = 0;

    while (i < n) {
        if (s[i] == '<') {
            inside_html_tag = 1;
            fputc(s[i++], out);
            continue;
        } else if (s[i] == '>') {
            inside_html_tag = 0;
            fputc(s[i++], out);
            continue;
        }

        if (inside_html_tag) {
            fputc(s[i++], out);
            continue;
        }

        if (isalpha((unsigned char)s[i])) {
            size_t tag_start = i;
            while (i < n && (isalnum((unsigned char)s[i]) || s[i] == '-')) i++;
            size_t tag_len = i - tag_start;

            // Skip spaces
            size_t j = i;
            while (j < n && isspace((unsigned char)s[j])) j++;

            if (j < n && s[j] == '"') {
                j++; // skip opening quote
                size_t text_start = j;
                int closed = 0;
                while (j < n) {
                    if (s[j] == '"' && s[j - 1] != '\\') { closed = 1; break; }
                    j++;
                }
                if (!closed) continue;

                size_t text_len = j - text_start;
                char tagbuf[64];
                if (tag_len >= sizeof(tagbuf)) tag_len = sizeof(tagbuf) - 1;
                memcpy(tagbuf, s + tag_start, tag_len);
                tagbuf[tag_len] = '\0';

                char *text = unescape(s + text_start, text_len);
                if (!text) text = strdup("");

                for (int k = 0; k < stack_top; k++) fputs("  ", out); // indent inline
                fprintf(out, "<%s>%s</%s>\n", tagbuf, text, tagbuf);
                free(text);

                i = j + 1;
                continue;
            } else {
                write_substr(out, s, tag_start, tag_len);
                i = tag_start + tag_len;
                continue;
            }
        } else {
            fputc(s[i], out);
            i++;
        }
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <file.webn>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        fprintf(stderr, "Error: cannot open file '%s'\n", argv[1]);
        return 2;
    }

    char outname[1024];
    strncpy(outname, argv[1], sizeof(outname) - 1);
    outname[sizeof(outname) - 1] = '\0';
    char *dot = strrchr(outname, '.');
    if (dot) strcpy(dot, ".html");
    else strcat(outname, ".html");

    FILE *out = fopen(outname, "wb");
    if (!out) {
        fprintf(stderr, "Error: cannot write to '%s'\n", outname);
        fclose(f);
        return 3;
    }

    char linebuf[LINE_MAX];
    while (fgets(linebuf, sizeof(linebuf), f)) {
        process_line(out, linebuf);
    }

    fclose(f);
    fclose(out);

    printf("Transpiled '%s' -> '%s'\n", argv[1], outname);
    return 0;
}

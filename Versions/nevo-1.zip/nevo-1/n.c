#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

#include <unistd.h>

#include "check_imports.h"
#include "auto_var.h"
#include "ban_list.h"
#include "replacements.h"
#include "arradd_recon.h"

const int replacements_count = sizeof(replacements) / sizeof(replacement_t);

void apply_replacements(char *line) {
    char buffer[1024];
    for (int r = 0; r < replacements_count; r++) {
        char *src = line;
        char *dst = buffer;
        buffer[0] = '\0';

        while (*src) {
            char *pos = strstr(src, replacements[r].from);
            if (pos) {
                int len = pos - src;
                memcpy(dst, src, len);
                dst += len;

                strcpy(dst, replacements[r].to);
                dst += strlen(replacements[r].to);

                src = pos + strlen(replacements[r].from);
            } else {
                strcpy(dst, src);
                break;
            }
        }

        strcpy(line, buffer); // copy back into original line
    }
}

void rtrim(char *s) {
    int len = strlen(s);
    while (len > 0 && isspace((unsigned char)s[len - 1])) {
        s[--len] = '\0';
    }
}

void remove_comments(char *line) {
    // Remove inline // comments
    char *comment = strstr(line, "//");
    if (comment) {
        *comment = '\0';
    }

    // Remove block /* */ comments (simple single-line version)
    char *start = strstr(line, "/*");
    while (start) {
        char *end = strstr(start + 2, "*/");
        if (end) {
            memmove(start, end + 2, strlen(end + 2) + 1); // remove comment
        } else {
            *start = '\0'; // no closing */, remove till end of line
            break;
        }
        start = strstr(line, "/*"); // check again
    }

    rtrim(line); // trim trailing spaces
}

int needs_semicolon(const char *line) {
    char tmp[1024];
    strncpy(tmp, line, sizeof(tmp));
    tmp[sizeof(tmp)-1] = 0;

    rtrim(tmp);

    if (strlen(tmp) == 0) return 0;
    if (tmp[0] == '#') return 0;
    if (tmp[0] == '/' && tmp[1] == '/') return 0;

    // Cut off inline comment
    char *comment = strstr(tmp, "//");
    if (comment) *comment = '\0';

    rtrim(tmp);  // trim again after cutting comment

    if (strlen(tmp) == 0) return 0;

    char last = tmp[strlen(tmp)-1];
    if (last == '{' || last == '}' || last == ';') return 0;

    return 1;
}

// copy the entire contents of `path` into the open FILE* out
// copy the contents of `path` into the open FILE* out, filtering duplicate includes and header guards.
// 'needed' indicates which headers were already printed (so we won't duplicate them).
static void paste_file_into_out(FILE *out, const char *path, headers_needed_t *needed) {
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "warning: could not open %s for injection\n", path);
        return;
    }

    // track which includes we've printed so far (start with what we already printed)
    int printed_stdio  = needed->stdio;
    int printed_stdlib = needed->stdlib;
    int printed_string = needed->string;
    int printed_math   = needed->math;
    int printed_ctype  = needed->ctype;
    int printed_time   = needed->time;
    int printed_assert = needed->assert;
    int printed_stdbool = needed->stdbool;

    char buf[4096];
    while (fgets(buf, sizeof(buf), f)) {
        // remove leading whitespace for easier detection
        char *p = buf;
        while (*p && isspace((unsigned char)*p)) p++;

        // skip header guards and pragmas
        if (strncmp(p, "#ifndef", 7) == 0) continue;
        if (strncmp(p, "#define", 7) == 0) continue;
        if (strncmp(p, "#endif", 6) == 0) continue;
        if (strncmp(p, "#pragma once", 11) == 0) continue;

        // detect include lines
        if (strncmp(p, "#include", 8) == 0) {
            // look for known headers
            if (strstr(p, "stdio.h")) {
                if (printed_stdio) continue;
                printed_stdio = 1;
            } else if (strstr(p, "stdlib.h")) {
                if (printed_stdlib) continue;
                printed_stdlib = 1;
            } else if (strstr(p, "string.h")) {
                if (printed_string) continue;
                printed_string = 1;
            } else if (strstr(p, "math.h")) {
                if (printed_math) continue;
                printed_math = 1;
            } else if (strstr(p, "ctype.h")) {
                if (printed_ctype) continue;
                printed_ctype = 1;
            } else if (strstr(p, "time.h")) {
                if (printed_time) continue;
                printed_time = 1;
            } else if (strstr(p, "assert.h")) {
                if (printed_assert) continue;
                printed_assert = 1;
            } else if (strstr(p, "stdbool.h")) {
                if (printed_stdbool) continue;
                printed_stdbool = 1;
            }
            // if it's an unknown include, still print it (could be user-provided dependency)
        }

        // write the (possibly filtered) original line to output
        fputs(buf, out);
    }

    // ensure separation
    fputs("\n", out);
    fclose(f);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input file> [input file2 ...]\n", argv[0]);
        return 1;
    }

    // Process each file in argv[1..argc-1]
    for (int file_idx = 1; file_idx < argc; file_idx++) {
        char *input_file = argv[file_idx];
        FILE *in = fopen(input_file, "r");
        if (!in) {
            perror("fopen input");
            continue; // skip to next file instead of aborting everything
        }

        // Determine output filename
        char output_file[256];
        strncpy(output_file, input_file, sizeof(output_file));
        output_file[sizeof(output_file)-1] = '\0';
        char *dot = strrchr(output_file, '.');
        if (dot) strcpy(dot, ".c");
        else strcat(output_file, ".c");

        // Read all lines into memory
        char *lines[1000];
        int num_lines = 0;
        char line[1024];
        int arradd_flag = 0;

        while (fgets(line, sizeof(line), in)) {
            rtrim(line);
            remove_comments(line);

            char tmp[1024];
            strncpy(tmp, line, sizeof(tmp));
            tmp[sizeof(tmp)-1] = 0;

            check_variable(tmp);
            check_ban_list(tmp);
            apply_replacements(tmp);

            if (arradd_used(line)) {
                arradd_flag = 1;
            }

            lines[num_lines++] = strdup(tmp);
        }
        fclose(in);

        // Open output file
        FILE *out = fopen(output_file, "w");
        if (!out) {
            perror("fopen output");
            for (int i = 0; i < num_lines; i++) free(lines[i]);
            continue;
        }

        // Calculate required headers
        headers_needed_t needed;
        calculate_needed_headers((const char **)lines, num_lines, &needed);

        // Write headers
        if (needed.stdio) fprintf(out, "#include <stdio.h>\n");
        if (needed.stdlib) fprintf(out, "#include <stdlib.h>\n");
        if (needed.string) fprintf(out, "#include <string.h>\n");
        if (needed.math) fprintf(out, "#include <math.h>\n");
        if (needed.ctype) fprintf(out, "#include <ctype.h>\n");
        if (needed.time) fprintf(out, "#include <time.h>\n");
        if (needed.assert) fprintf(out, "#include <assert.h>\n");
        if (needed.stdbool) fprintf(out, "#include <stdbool.h>\n");

        // Inject arradd if needed
        if (arradd_flag) {
            fprintf(out, "\n// --- arradd implementation (injected from arradd.c) ---\n");
            paste_file_into_out(out, "arradd.c", &needed);
            fprintf(out, "// --- end arradd implementation ---\n\n");
        }

        // Write processed lines
        for (int i = 0; i < num_lines; i++) {
            char *l = lines[i];
            if (needs_semicolon(l)) strcat(l, ";");
            fprintf(out, "%s\n", l);
            free(l);
        }

        fclose(out);
        printf("Processed %s -> %s\n", input_file, output_file);

        // Use clang instead of GCC
        #if defined(_WIN32) || defined(_WIN64)
            const char *compiler = "C:\\nevo\\mingw64\\mingw64\\bin\\gcc.exe";
        #else
            const char *compiler = "clang";
        #endif
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "%s %s -o %.*s", compiler, output_file, (int)(dot - output_file), output_file); 
        // -o output_file (without .c)

        int ret = system(cmd);
        if (ret == 0) {
            printf("Compilation succeeded: %.*s\n", (int)(dot - output_file), output_file);
        } else {
            printf("Compilation failed with code %d\n", ret);
        }

    }

    return 0;
}

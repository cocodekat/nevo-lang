#!/bin/bash

TARGET_DIR="$HOME/nevo"
mkdir -p "$TARGET_DIR"

echo "Installing Python to $TARGET_DIR/python (This might take a moment)"

# Download & extract Python silently
curl -s -O https://www.python.org/ftp/python/3.12.6/Python-3.12.6.tar.xz
tar -xf Python-3.12.6.tar.xz
cd Python-3.12.6 || exit 1

# Configure, build, and install Python silently
./configure --prefix="$TARGET_DIR/python" --enable-optimizations >/dev/null 2>&1
make -j >/dev/null 2>&1
make install >/dev/null 2>&1

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Compiling Nevo Compiler..."
clang "$SCRIPT_DIR/../nevo.c"   -o "$TARGET_DIR/nevo"
clang "$SCRIPT_DIR/../n.c"      -o "$TARGET_DIR/n"
clang "$SCRIPT_DIR/../web-n.c"  -o "$TARGET_DIR/webn"

echo "Moving arradd.c..."
mv "$SCRIPT_DIR/arradd.c" "$TARGET_DIR"

echo "Cleaning up temporary Python files..."
rm -rf Python-3.12.6 Python-3.12.6.tar.xz

echo "✅ Done! Everything you need is inside of $TARGET_DIR"
read -p "Press Enter to continue..."

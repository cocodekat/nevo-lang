#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <mode> <input file>\n", argv[0]);
        printf("Modes:\n");
        printf("  -n   Compile .n file (C transpile + compile)\n");
        printf("  -w   Transpile .webn -> .html\n");
        printf("  -wa  Transpile .webn -> Python webview -> macOS app\n");
        return 1;
    }

    const char *mode = argv[1];
    const char *input = argv[2];
    char cmd[1024];

    // -------------------------
    // Mode: -n (run n compiler)
    // -------------------------
    if (strcmp(mode, "-n") == 0) {
        #if defined(_WIN32) || defined(_WIN64)
            snprintf(cmd, sizeof(cmd), "C:\\nevo\\n %s", input);
        #else
            snprintf(cmd, sizeof(cmd), "$HOME/nevo/n %s", input);
        #endif
            printf("[nevo] Running n compiler: %s\n", cmd);
            int ret = system(cmd);
            if (ret != 0) {
                fprintf(stderr, "[nevo] n compiler failed with code %d\n", ret);
                return ret;
            }
            printf("[nevo] .n compilation complete.\n");
            return 0;
    }
    // -------------------------
    // Mode: -w (run webn compiler)
    // -------------------------
    else if (strcmp(mode, "-w") == 0) {
        #if defined(_WIN32) || defined(_WIN64)
            snprintf(cmd, sizeof(cmd), "C:\\nevo\\webn %s", input);
        #else
            snprintf(cmd, sizeof(cmd), "$HOME/nevo/webn %s", input);
        #endif
        printf("[nevo] Running webn compiler: %s\n", cmd);
        int ret = system(cmd);
        if (ret != 0) {
            fprintf(stderr, "[nevo] webn compiler failed with code %d\n", ret);
            return ret;
        }
        printf("[nevo] .webn → .html transpilation complete.\n");
        return 0;
    }

    // -------------------------
    // Mode: -wa (webn → app)
    // -------------------------
        // -------------------------
    // Mode: -wa (webn → app)
    // -------------------------
    else if (strcmp(mode, "-wa") == 0) {
        // Step 1: transpile .webn to .html
        snprintf(cmd, sizeof(cmd), "./webn %s", input);
        printf("[nevo] Running webn compiler: %s\n", cmd);
        int ret = system(cmd);
        if (ret != 0) {
            fprintf(stderr, "[nevo] webn compiler failed with code %d\n", ret);
            return ret;
        }

        // Step 2: generate .py launcher
        char base[512];
        strncpy(base, input, sizeof(base));
        base[sizeof(base) - 1] = '\0';
        char *dot = strrchr(base, '.');
        if (dot) *dot = '\0'; // remove extension

        char pyfile[512];
        snprintf(pyfile, sizeof(pyfile), "%s_app.py", base);

        FILE *py = fopen(pyfile, "w");
        if (!py) {
            perror("fopen python file");
            return 1;
        }

        fprintf(py,
            "#!/usr/bin/env python3\n"
            "import sys, os, webview\n"
            "\n"
            "def resource_path(relative_path):\n"
            "    try:\n"
            "        base_path = sys._MEIPASS\n"
            "    except AttributeError:\n"
            "        base_path = os.path.abspath('.')\n"
            "    return os.path.join(base_path, relative_path)\n"
            "\n"
            "html_file = resource_path('%s.html')\n"
            "webview.create_window('My App', html_file)\n"
            "webview.start()\n",
            base
        );

        fclose(py);
        printf("[nevo] Generated Python app: %s\n", pyfile);

        // Step 3: OS-specific PyInstaller build
    #if defined(_WIN32) || defined(_WIN64)
        snprintf(cmd, sizeof(cmd),
            "C:\\python-portable\\python.exe -m PyInstaller --onefile --windowed --log-level=WARN "
            "--hidden-import=pywebview --hidden-import=webview "
            "--add-data \"%s.html;.\" \"%s\"",
            base, pyfile);
    #elif defined(__APPLE__)
        snprintf(cmd, sizeof(cmd),
            "$HOME/python-portable/bin/python3.12 -m PyInstaller --onedir --windowed --log-level=WARN --noconfirm --clean "
            "--hidden-import=pywebview --hidden-import=webview "
            "--add-data \"%s.html:.\" \"%s\"",
            base, pyfile);
    #else
        fprintf(stderr, "[nevo] Unsupported OS for -wa mode.\n");
        return 1;
    #endif

        printf("[nevo] Compiling app using PyInstaller...\n");
        ret = system(cmd);
        if (ret != 0) {
            fprintf(stderr, "[nevo] PyInstaller build failed with code %d\n", ret);
            return ret;
        }

        printf("[nevo] App build complete.\n");
        return 0;
    }



    else {
        fprintf(stderr, "Unknown mode: %s\n", mode);
        return 2;
    }
}


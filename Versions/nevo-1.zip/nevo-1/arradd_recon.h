#ifndef ARRADD_RECON_H
#define ARRADD_RECON_H

#include <string.h>

// Simple helper: returns true if the line uses arradd()
static int arradd_used(const char *line) {
    return strstr(line, "arradd") != NULL;
    return strstr(line, "carr") != NULL;
    return strstr(line, "farr") != NULL;
    return strstr(line, "parr") != NULL;

    return strstr(line, "_int") != NULL;
    return strstr(line, "_str") != NULL;
    return strstr(line, "_float") != NULL;
    return strstr(line, "_double") != NULL;
    return strstr(line, "_char") != NULL;
    return strstr(line, "_bool") != NULL;
}

#endif // ARRADD_RECON_H
